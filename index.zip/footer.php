</main>
<footer class="bg-light text-center py-3 mt-auto">
    <small>&copy; <?=date('Y')?> SecureAuth Demo</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
